<div class="pxl-navigation-carousel <?php echo esc_attr($settings['style']); ?>">
        <div class="pxl-navigation-arrow pxl-navigation-arrow-prev" style="transform:scalex(-1);"><i class="flaticon flaticon-next" ></i></div>
        <div class="pxl-navigation-arrow pxl-navigation-arrow-next"><i class="flaticon flaticon-next"></i></div>
</div>