<?php

$uri = get_template_directory_uri() . '/inc/admin/demo-data/demo-imgs/';
// Demos
$demos = array(
	// Elementor Demos
	'medicross' => array(
		'title'       => 'Medicross',	
		'description' => '',
		'screenshot'  => $uri . 'screenshot.webp',
		'preview'     => 'https://demo.casethemes.net/medicross/landing',
	),
);